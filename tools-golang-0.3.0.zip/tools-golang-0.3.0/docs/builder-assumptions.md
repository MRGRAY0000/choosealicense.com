SPDX-License-Identifier: CC-BY-4.0

The Document builder in `package builder` makes the following assumptions:

- Symbolic links will be ignored and will not be included in the Document's Files (see
  https://github.com/swinslow/spdx-go/issues/13).
