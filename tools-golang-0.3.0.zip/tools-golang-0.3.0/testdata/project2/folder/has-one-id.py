# a comment in the python file
# SPDX-License-Identifier: MIT

if __name__ == "__main__":
    print("Hello world!")
